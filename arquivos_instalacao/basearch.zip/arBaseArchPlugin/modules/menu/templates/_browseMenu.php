	<?php
	/** CUSTOMIZAÇÃO COC 
	 *** Data: 20140813
	 *** Responsável: STI COC
	 *** e-mail: sistemasti@coc.fiocruz.br
	 *** Ação: Menu Browse Aberto
	 */
	?>

	<div class="menu-principal">
		<ul>
			<?php echo QubitMenu::displayHierarchyAsList($browseMenu, 0) ?>
		</ul>
	</div>