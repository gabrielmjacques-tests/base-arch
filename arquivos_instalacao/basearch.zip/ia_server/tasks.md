# Tarefas
- [x] Descrição de modelo está resetando após salvar
- [x] Adicionar link de documentação para cada IA
- [ ] Alterar modelo de resposta bem-sucedida para deixar em português (deve-se também alterar no tema da BaseArch)
- [ ] Adicionar forma de enviar informações extras (Nome da imagem, sobre quem se trata, etc)
- [ ] Remover prefixo 'api'
- [ ] Tratar melhor o erro de arquivo invalido

## Sobre a Documentação, lembrar de:
- [ ] Adicionar explicação sobre como adicionar ou alterar modelos