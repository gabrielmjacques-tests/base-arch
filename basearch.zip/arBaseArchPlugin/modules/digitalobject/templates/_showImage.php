<?php use_helper('Text'); ?>

<?php if (QubitTerm::MASTER_ID == $usageType || QubitTerm::REFERENCE_ID == $usageType) { ?>

  <?php if (isset($link)) { ?>
    <?php echo link_to(image_tag($representation->getFullPath(), ['alt' => __($resource->getDigitalObjectAltText() ?: 'Open original %1%', ['%1%' => sfConfig::get('app_ui_label_digitalobject')])]), $link, ['target' => '_blank']); ?>
  <?php } else { ?>
    <?php echo image_tag($representation->getFullPath(), ['alt' => __($resource->getDigitalObjectAltText() ?: 'Original %1% not accessible', ['%1%' => sfConfig::get('app_ui_label_digitalobject')])]); ?>
  <?php } ?>

  <button id="describe-btn" onclick="descreverImagem()">Descrever Imagem</button>
  <span id="descricao-imagem"></span>

<?php } elseif (QubitTerm::THUMBNAIL_ID == $usageType) { ?>

  <?php if ($iconOnly) { ?>
    <?php if (isset($link)) { ?>
      <?php echo link_to(image_tag($representation->getFullPath(), ['alt' => __($resource->getDigitalObjectAltText() ?: 'Open original %1%', ['%1%' => sfConfig::get('app_ui_label_digitalobject')])]), $link); ?>
    <?php } else { ?>
      <?php echo image_tag($representation->getFullPath(), ['alt' => __($resource->getDigitalObjectAltText() ?: 'Original %1% not accessible', ['%1%' => sfConfig::get('app_ui_label_digitalobject')])]); ?>
    <?php } ?>

  <?php } else { ?>

    <div class="digitalObject">

      <div class="digitalObjectRep">
        <?php if (isset($link)) { ?>
          <?php echo link_to(image_tag($representation->getFullPath(), ['alt' => __($resource->getDigitalObjectAltText() ?: 'Open original %1%', ['%1%' => sfConfig::get('app_ui_label_digitalobject')])]), $link); ?>
        <?php } else { ?>
          <?php echo image_tag($representation->getFullPath(), ['alt' => __($resource->getDigitalObjectAltText() ?: 'Original %1% not accessible', ['%1%' => sfConfig::get('app_ui_label_digitalobject')])]); ?>
        <?php } ?>
      </div>

      <div class="digitalObjectDesc">
        <?php echo wrap_text($resource->name, 18); ?>
      </div>

    </div>

  <?php } ?>

<?php } ?>
<script defer>
  const descricaoImagem = document.getElementById('descricao-imagem')
  
  // Send image from tag as FormData to the server
  function descreverImagem() {
  descricaoImagem.textContent = 'Gerando...'

  var formData = new FormData();

  // Seleciona a tag <img>
  var imgElement = document.querySelector('.digital-object-reference img'); // ajuste o seletor conforme necessário

  // Pega a URL da imagem
  var imageUrl = imgElement.src;

  // Faz o download da imagem como Blob
  fetch(imageUrl)
    .then(response => response.blob()) // converte a resposta para Blob
    .then(blob => {
      // Adiciona a imagem Blob ao FormData, simulando um arquivo
      formData.append('image', blob, 'image.jpg'); // 'image.jpg' é o nome do arquivo

      // Faz o POST do FormData
      return fetch('/api/describe-image', {
        method: 'POST',
        body: formData
      });
    })
    .then(response => response.json())
    .then(data => {
      descricaoImagem.textContent = `Gerado por IA: ${data.text}`
    })
    .catch(error => {
      console.error('Erro:', error);
      descricaoImagem.textContent = 'Não foi possível gerar uma descrição no momento'
    });
}


</script>