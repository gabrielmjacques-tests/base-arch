<!--
Antiga barra de governo
<div id="barra-brasil" style="background:#7F7F7F; height: 20px; padding:0 0 0 10px;display:block;">
	<ul id="menu-barra-temp" style="list-style:none;">
		<li style="display:inline; float:left;padding-right:10px; margin-right:10px; border-right:1px solid #EDEDED"><a
				href="http://brasil.gov.br"
				style="font-family:sans,sans-serif; text-decoration:none; color:white;">Portal do Governo Brasileiro</a>
		</li>
		<li><a style="font-family:sans,sans-serif; text-decoration:none; color:white;"
				href="http://epwg.governoeletronico.gov.br/barra/atualize.html">Atualize sua Barra de Governo</a></li>
	</ul>
</div>
-->

<script defer>
	/*
	 * Script para descrever imagens utilizando uma API de IA.
	 * 
	 * Este script utiliza a API de descrição de imagens para gerar uma descrição
	 * de uma imagem exibida na página.
	 */


	/**
	 * Troca o texto de um elemento com animações de saída e entrada.
	 * @param {HTMLElement} element - Elemento cujo texto será alterado.
	 * @param {string} novoTexto - Novo texto a ser exibido.
	 * @param {string} novaClasse - Classe CSS a ser aplicada ao elemento.
	 */
	async function executarTransicaoTexto(element, novoTexto, novaClasse) {
		// Inicia a animação de saída
		element.classList.add('animar-sair');
		await new Promise((resolve) => setTimeout(resolve, 500)); // Aguarda o fim da animação

		// Troca o texto e aplica a nova classe com animação de entrada
		element.textContent = novoTexto;
		element.className = novaClasse; // Remove outras classes e aplica a nova
		element.classList.add('animar-aparecer');
	}

	/**
	 * Descreve uma imagem utilizando uma API de IA.
	 * @param {HTMLElement} textElement - Elemento onde a descrição será exibida.
	 * @param {HTMLImageElement} imageElement - Elemento da imagem a ser descrita.
	 * @returns {Promise<boolean>} - Promessa que resolve com true se a descrição foi gerada com sucesso.
	 */
	async function exibirDescricaoComAnimacao(textElement, imageElement) {

		// Mostra o texto inicial de carregamento com animação
		executarTransicaoTexto(
			textElement,
			'Gerando descrição...',
			'descricao-ia-carregando'
		);

		try {
			// Cria o FormData e adiciona a imagem como Blob
			const formData = new FormData();
			const imageUrl = imageElement.src;
			const response = await fetch(imageUrl);
			const blob = await response.blob();
			formData.append('image', blob, 'image.jpg');

			// Faz o POST para a API para descrever a imagem
			const describeResponse = await fetch('/api/describe-image', {
				method: 'POST',
				body: formData,
			});

			// Verifica se a requisição falhou
			if (!describeResponse.ok) {
				throw new Error('Erro ao descrever imagem');
			}

			// Processa a resposta e atualiza o texto com a descrição gerada
			const data = await describeResponse.json();
			await executarTransicaoTexto(
				textElement,
				`Gerado por IA: ${data.text}`,
				'descricao-ia-sucesso'
			);

			return true;
		} catch (error) {
			// Exibe uma mensagem de erro com animação
			await executarTransicaoTexto(
				textElement,
				'Não foi possível gerar uma descrição no momento',
				'descricao-ia-erro'
			);

			return false;
		}
	}

	/**
	 * Envia uma imagem para a API e retorna a descrição gerada.
	 * @param {HTMLImageElement} imageElement - Elemento de imagem contendo a URL da imagem a ser enviada.
	 * @returns {Promise<string>} - Retorna a descrição gerada pela API.
	 * @throws {Error} - Lança um erro se o envio ou o processamento falhar.
	 */
	async function obterDescricaoIA(imageElement) {
		try {
			// Cria o FormData e adiciona a imagem como Blob
			const formData = new FormData();
			const imageUrl = imageElement.src;
			const response = await fetch(imageUrl);
			const blob = await response.blob();
			formData.append('image', blob, 'image.jpg');

			// Faz o POST para a API e processa a resposta
			const describeResponse = await fetch('/api/describe-image', {
				method: 'POST',
				body: formData,
			});

			if (!describeResponse.ok) {
				throw new Error('Falha ao obter resposta da API');
			}

			const data = await describeResponse.json();
			return data.text; // Retorna a descrição gerada
		} catch (error) {
			console.error('Erro ao enviar a imagem:', error);
			throw error; // Repassa o erro para tratamento externo
		}
	}
</script>

<script type="text/javascript">
	Shadowbox.init();
</script>
<?php echo get_component('default', 'updateCheck') ?>

<header id="top-bar">

	<!-- Botão para pular a navegação e ir direto para o conteúdo principal da página -->
	<a href="#main-column" class="pular-para-conteudo" aria-label="Pular para o conteúdo principal">Pular para o
		conteúdo principal</a>

	<?php
	/** CUSTOMIZAÇÃO COC 
	 *** Data: 20141006 - Atualizado em: 2021-05-19
	 *** Responsável: STI COC
	 *** e-mail: sistemasti@coc.fiocruz.br
	 *** Ações: Inclusão de estrutura para abrigar o banner da base arch, que contém link para o Portal COC
	 */
	?>

	<div id="header-logo"> <?php //customização 
							?>

		<?php if (sfConfig::get('app_toggleLogo')): ?>
			<div id="logo-coc"> <?php //customização 
								?>

				<?php echo link_to('<span class="escondidinho">Portal COC</span>', 'http://www.coc.fiocruz.br', array('id' => 'logo', 'title' => 'Vai para o Portal da COC', 'target' => '_blank')) ?>

			</div> <?php //customização 
					?>
		<?php endif; ?>




		<?php if (sfConfig::get('app_toggleTitle')): ?>
			<h1 id="site-name">
				<?php echo link_to('<span>' . sfConfig::get('app_siteTitle') . '</span>', '@homepage', array('rel' => 'home', 'title' => __('Home'))) ?>
			</h1>
		<?php endif; ?>
	</div> <?php //customização 
			?>

	<nav class="menu-secundario">

		<?php echo get_component('menu', 'userMenu') ?>

		<?php echo get_component('menu', 'clipboardMenu') ?>

		<?php echo get_component('menu', 'quickLinksMenu') ?>

		<?php //echo get_component('menu', 'changeLanguageMenu') 
		?>

		<?php echo get_component('menu', 'mainMenu', array('sf_cache_key' => $sf_user->getCulture() . $sf_user->getUserID())) ?>

	</nav>

	<?php echo get_component_slot('header') ?>

</header>

<!--FORMULÁRIO DE PESQUISA COC-->
<!-- <div>
	<a href="https://forms.office.com/Pages/ResponsePage.aspx?id=piE3vGGAGU6jtDHiCT4gmntH0MsB6QFBmkJyb_gsbGpUMDJXUlQ1TEc2MzFUQVVRME00S0hDM0tVRC4u" target="_blank" class="pesquisa">Pesquisa</a>
</div> -->
<!--FIM DO FORMULÁRIO DE PESQUISA COC -->

<?php if (sfConfig::get('app_toggleDescription')): ?>
	<div id="site-slogan">
		<div class="container">
			<div class="row">
				<div class="span12">
					<span><?php echo sfConfig::get('app_siteDescription') ?></span>
				</div>
			</div>
		</div>
	</div>
<?php else: ?>
	<div id="site-slogan">
		<div id="search-bar">
			<?php echo get_component('search', 'box') ?>

		</div>
	</div>

<?php endif; ?>

<?php echo get_component('menu', 'browseMenu', array('sf_cache_key' => $sf_user->getCulture() . $sf_user->getUserID())) ?>