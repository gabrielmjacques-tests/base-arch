import { GoogleGenerativeAI } from "@google/generative-ai"
import logger from "../utils/logger.js"

// Configurações do modelo Gemini que podem ser alteradas via API
let geminiConfig = {
    model: "gemini-1.5-flash",
    generationConfig: {
        maxOutputTokens: 200
    }
}

// Prompt padrão que pode ser alterado via API
let defaultPrompt = `Describe this image in detail without referencing any camera-related terms such as 'angle,' 'focus,' or 'shot.' Focus on the important visual elements, including colors, shapes, sizes, and textures. Provide context if possible, ensuring clarity and accessibility. The response must be written in Portuguese.
`

// Mensagens de erro
const ERROR_MESSAGES = {
    NO_IMAGE: "Nenhuma imagem foi enviada.",
    PROCESSING_ERROR: "Houve um erro ao tentar descrever a imagem. Por favor, tente novamente."
}

// Funções para atualizar configurações
const updateConfig = (newConfig) => {
    if (newConfig.model) geminiConfig.model = newConfig.model
    if (newConfig.maxOutputTokens) geminiConfig.generationConfig.maxOutputTokens = newConfig.maxOutputTokens
}

const updatePrompt = (newPrompt) => {
    defaultPrompt = newPrompt
}

export default {
    describeImage: async (req, res) => {
        const file = req.file

        // Validação inicial
        if (!file) {
            return res.status(400).json({ text: ERROR_MESSAGES.NO_IMAGE })
        }

        try {
            // Inicialização do modelo
            const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY)
            const model = genAI.getGenerativeModel(geminiConfig)

            // Preparação dos dados da imagem
            const imageData = {
                inlineData: {
                    data: file.buffer.toString("base64"),
                    mimeType: file.mimetype
                }
            }

            // Geração da descrição
            const result = await model.generateContent([imageData, { text: defaultPrompt }])
            let text = (await result.response).text()

            text = text.substring(0, text.lastIndexOf('.') + 1)

            return res.status(200).json({ text })
        } catch (error) {
            logger.error(error)
            return res.status(500).json({ text: ERROR_MESSAGES.PROCESSING_ERROR })
        }
    },
    updateConfig,
    updatePrompt,
    getConfig: () => ({ ...geminiConfig, prompt: defaultPrompt })
}