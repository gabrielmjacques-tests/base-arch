import { GoogleGenerativeAI } from "@google/generative-ai";
import logger from "../utils/logger.js";

export default {
    describeImage: async (req, res) => {
        const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);
        const file = req.file;

        // Verifica se o arquivo foi enviado
        if (!file) {
            res.status(400).json({ text: "Nenhuma imagem foi enviada." });
            return;
        }

        // Cria um modelo generativo
        const model = genAI.getGenerativeModel({
            model: "gemini-1.5-flash", // Modelo de descrição de imagens
            generationConfig: {
                maxOutputTokens: 100, // Tamanho máximo da descrição (em tokens)
            }
        });
        model.safetySettings;

        const mimeType = file.mimetype; // Tipo de arquivo
        const buffer = file.buffer.toString("base64"); // Dados da imagem em base64
        const prompt = `
        Describe this image in detail without referencing any camera-related terms such as 'angle,' 'focus,' or 'shot.' Focus on the important visual elements, including colors, shapes, sizes, and textures. Provide context if possible, ensuring clarity and accessibility. The response must be written in Portuguese.
        `;

        try {
            const result = await model.generateContent(
                [
                    {
                        inlineData: {
                            data: buffer,
                            mimeType,
                        }
                    },
                    { text: prompt }
                ]);
            const response = await result.response;
            const text = response.text();

            res.status(200).json({ text });
        } catch (error) {
            logger.error(error);
            res.status(500).json({ text: "Houve um erro ao tentar descrever a imagem. Por favor, tente novamente." });
        }
    }
};