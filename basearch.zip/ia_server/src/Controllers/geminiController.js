import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI("AIzaSyAPMcX5afHgXSvKY3esDYlCHIZQm4dYYKw");

export const geminiController = {
    generateText: async (req, res) => {
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

        const prompt = req.body.prompt;

        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();

        res.json({ text });
    },

    describeImage: async (req, res) => {
        const file = req.file;
        if (!file) {
            res.status(400).json({ message: "No image file uploaded" });
            return;
        }

        const model = genAI.getGenerativeModel({
            model: "gemini-1.5-flash",
            generationConfig: {
                maxOutputTokens: 200,
            }
        });
        model.safetySettings;

        const mimeType = file.mimetype;
        const buffer = file.buffer.toString("base64");
        const prompt = `
        Describe the photo concisely and briefly. Include information about people, objects, facial expressions, the environment, and other important elements. If there are people, provide details about them. Provide the answer in Brazilian Portuguese.
        `;

        try{
        const result = await model.generateContent(
            [
                {
                    inlineData: {
                        data: buffer,
                        mimeType,
                    }
                },
                { text: prompt }
            ]);
        const response = result.response;
        const text = response.text();

        res.json({ text });

    } catch(err){
        console.log(err)
        res.json({text: "Server problem"})
    }

    }
};
