import { Router } from "express"
import geminiController from "../Controllers/geminiController.js"
const router = Router()

// Rota de Teste para uma página de geração de imagens
export const testEndpoint = 'test-descriptions'
router.get(`/api/${testEndpoint}`, (req, res) => {
    res.sendFile("describeImage.html", { root: "./src/public" })
})

// Rota para obter configurações da API
router.get("/api/config", (req, res) => {
    res.json({
        geminiConfig: geminiController.getConfig()
    })
})

// Rota para atualizar configurações da API
router.post("/api/config", (req, res) => {
    const { model, maxOutputTokens, prompt } = req.body

    try {
        if (model) geminiController.updateConfig({ model })
        if (maxOutputTokens) geminiController.updateConfig({ maxOutputTokens })
        if (prompt) geminiController.updatePrompt(prompt)
        res.json({ message: "Configurações atualizadas com sucesso" })
    } catch (error) {
        res.status(500).json({ message: "Erro ao atualizar configurações" })
    }
})

export default router
