import { Router } from "express";
import geminiController from "../Controllers/geminiController.js";
import multer from "multer";

const router = Router();

// Rota de Teste para uma página de geração de imagens
router.get("/api/describe-image", (req, res) => {
    res.sendFile("describeImage.html", { root: "./src/views" });
});

// Rota de API para geração de imagens
router.post("/api/describe-image", multer().single("image"), geminiController.describeImage);

export default router;
