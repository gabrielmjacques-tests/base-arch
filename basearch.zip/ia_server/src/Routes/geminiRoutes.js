import { Router } from "express"
import geminiController from "../Controllers/geminiController.js"
import multer from "multer"

const router = Router()

// Rota de API para geração de imagens
router.post("/api/describe-image", multer().single("image"), geminiController.describeImage)

export default router