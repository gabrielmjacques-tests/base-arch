import { Router } from "express";
import { geminiController } from "../Controllers/geminiController.js";
import multer from "multer";

const router = Router();

router.get("/api/test", (req, res) => {
    res.json({ message: "Hello, world!" });
});

router.get("/api/generate-text", (req, res) => {
    res.sendFile("generateText.html", { root: "./src/views" });
});
router.post("/api/generate-text", geminiController.generateText);

router.get("/api/describe-image", (req, res) => {
    res.sendFile("describeImage.html", { root: "./src/views" });
});
router.post("/api/describe-image", multer().single("image"), geminiController.describeImage);

export default router;
