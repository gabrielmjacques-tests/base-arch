import express from "express"
import dotenv from "dotenv"
import geminiRoutes from "./Routes/geminiRoutes.js"
import configRoutes, { testEndpoint } from "./Routes/configRoutes.js"
import cors from "cors"

console.clear()

const app = express()
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(cors({
    origin: "http://localhost"
}))

dotenv.config()
const mode = process.env.MODE
const serverPort = process.env.SERVER_PORT

app.use(geminiRoutes)
app.use(configRoutes)

app.listen(serverPort, () => {
    console.log(`Servidor rodando na porta ${serverPort}`)

    if (mode == 'dev') {
        console.log(`Em modo de Desenvolvimento`)
        console.log(`Interface Web para testes: http://localhost:${serverPort}/api/${testEndpoint}`)
    }
    else if (mode == 'prod')
        console.log(`Em modo de Produção`)
})